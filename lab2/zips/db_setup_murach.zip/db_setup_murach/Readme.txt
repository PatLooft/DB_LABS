To create users and tables in Murach's book,
  run the batch file setup_database.bat.
  This batch file will run other SQL scripts in this folder.