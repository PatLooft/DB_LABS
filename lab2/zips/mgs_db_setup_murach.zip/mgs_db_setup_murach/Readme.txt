Download and unzip the file mgs_db_setup_murach.zip.

Then run SetupMGSDB.bat just like when you run setup_database.bat for Murach Lab DB.