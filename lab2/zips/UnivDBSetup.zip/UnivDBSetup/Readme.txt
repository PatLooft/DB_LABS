Download and unzip the file SetupUnivDB.zip.

Then run SetupUnivDB.bat just like when you run setup_database.bat for Lab DB.